<nav class="navbar navbar-expand-lg navbar-light bg-danger text-white">
  <div class="container">
    <a class="navbar-brand">Catatan Pemeriksaan Rutin Sapi</a>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <a class="nav-link" href="/pemeriksaan">Pemeriksaan</a>

      </div>

    </div>
    <!-- <form class="d-flex">
      <input class="form-control me-2" type="search" placeholder="Ear Tag" aria-label="Search" />
      <button class="btn btn-outline-dark" type="submit">Search</button>
    </form>
  </div> -->
</nav>